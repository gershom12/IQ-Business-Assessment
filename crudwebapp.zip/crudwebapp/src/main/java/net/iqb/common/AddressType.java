package net.iqb.common;

/**
 *
 * @author gershom
 */
public enum AddressType {

    POSTAL,
    RESIDENTIAL
}
