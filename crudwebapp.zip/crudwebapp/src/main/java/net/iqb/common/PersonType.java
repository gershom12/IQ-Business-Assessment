package net.iqb.common;

/**
 *
 * @author gershom
 */
public enum PersonType {

    SYSTEM_USER,
    EMPLOYEE
}
